<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Online Food Delivery System</title>
    
    <!-- load CSS -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600"
    />
    <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="slick/slick.css" />
    <link rel="stylesheet" href="slick/slick-theme.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />
    <link rel="stylesheet" href="css/tooplate-style.css" />
    <link href="tooplate_style1.css" rel="stylesheet" type="text/css" />
    <!-- Templatemo style -->
  </head>

  <body>
    <!-- Loader -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>

    <div class="tm-main-container">
      <div class="tm-top-container">


        <!-- Menu -->
        <nav id="tmNav" class="tm-nav">
        	 
          <a class="tm-navbar-menu" href="#"><b><i>Admin Menu Button</i></b></a>
          <ul class="tm-nav-links">

            <li class="tm-nav-item active">
              <a href="home.php" class="tm-navbar-menu"><b>Home</b></a>
            </li>

            <li class="tm-nav-item">
              <a href="insert.php" class="tm-navbar-menu"><b>Insert</b></a>
            </li>

            <li class="tm-nav-item">
              <a href="view-product.php" class="tm-navbar-menu"><b>Product</b></a>                
            </li>

            <li class="tm-nav-item">
              <a href="view-order.php" class="tm-navbar-menu"><b>Order</b></a>
            </li>
            
            <li class="tm-nav-item">
              <a href="view-feedback.php" class="tm-navbar-menu"><b>Feedback</b></a>
            </li>


            <li class="tm-nav-item">
              <a href="logout.php" class="tm-navbar-menu"><b>Log Out</b></a>
            </li>

          </ul>
        </nav>
		
		<header class="tm-site-header-box1 tm-bg-dark">

          <h1 class="tm-site-title"><img src="img/fooddelivery.webp" width="150" height="90"> <b><i>Yummy Capital</i></b></h1><br>
		  
		 </header>
		 
		</div><!-- END of tm-top-container -->

        <!-- Site header -->
        <header class="tm-site-header-box tm-bg-dark">

          <h1 class="tm-site-title"> View Order form</h1><br>
          <form  name="testform" method="post" enctype="multipart/form-data" >
			<table style="border-color:white;border-style: dotted;margin-left:5px;" border="1" width="900px" align="left">
				
						
				
				<tr>	<th width="100px" height="50px">ID:</b></th>					
						<th width="100px" height="50px"><b>Order Name:</b></th>
						<th width="100px" height="50px"><b>Price:</b></th>
						<th width="100px" height="50px"><b>Customer Name</b></th>
						<th width="100px" height="50px"><b>Phone:</b></th>
						<th width="100px" height="50px"><b>Address</b></th>	
						<th width="100px" height="50px"><b>Order No:</b></th>						
				</tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from orders ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['ord_id'];					
									$prodno=$row['productno'];
									$price=$row['price'];
									$name=$row['name'];
									$phone=$row['phone'];
									$address=$row['address'];
									$ordno=$row['order_no'];
						?>
					 <tr>
						
						<td width="100px" height="50px"><?php echo $id; ?></td>
						<td width="100px" height="50px"><?php echo $prodno; ?></td>
						<td width="100px" height="50px"><?php echo $price; ?></td>
						<td width="100px" height="50px"><?php echo $name; ?></td>
						<td width="100px" height="50px"><?php echo $phone; ?></td>
						<td width="100px" height="50px"><?php echo $address; ?></td>
						<td width="100px" height="50px"><?php echo $ordno; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
			</table>
			</form>
				<h2><?php echo $err;?></h2>
	<a href="view-feedback.php"  class="tm-link"><b><i>Next to view feedback</i></b></a>	
        </header>
 

      		

      <div class="tm-bottom-container">
        

        <!-- Footer -->
        <footer>
          || Developed by &copy; Hein Min Htet in Page Myanmar.  
           Location &copy; Thunandar 1st , No(682) , North Okkalapa Tel: 09787267744 ||
        
        </footer>
      
    </div>
	</div><!-- END of tm-main-container -->
<?php }  ?>
	

    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/background.cycle.js"></script>
    <script src="slick/slick.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script>
      let slickInitDone = false;
      let previousImageId = 0,
        currentImageId = 0;
      let pageAlign = "right";
      let bgCycle;
      let links;
      let eachNavLink;

      window.onload = function() {
        $("body").addClass("loaded");
      };

      function navLinkClick(e) {
        if ($(e.target).hasClass("external")) {
          return;
        }

        e.preventDefault();

        if ($(e.target).data("align")) {
          pageAlign = $(e.target).data("align");
        }

        // Change bg image
        previousImageId = currentImageId;
        currentImageId = $(e.target).data("linkid");
        bgCycle.cycleToNextImage(previousImageId, currentImageId);

        // Change menu item highlight
        $(`.tm-nav-item:eq(${previousImageId})`).removeClass("active");
        $(`.tm-nav-item:eq(${currentImageId})`).addClass("active");

        // Change page content
        $(`.tm-section-${previousImageId}`).fadeOut(function(e) {
          $(`.tm-section-${currentImageId}`).fadeIn();
          // Gallery
          if (currentImageId === 2) {
            setupSlider();
          }
        });

        adjustFooter();
      }

      $(document).ready(function() {
        // Set first page
        $(".tm-section").fadeOut(0);
        $(".tm-section-0").fadeIn();

        // Set Background images
        // https://www.jqueryscript.net/slideshow/Simple-jQuery-Background-Image-Slideshow-with-Fade-Transitions-Background-Cycle.html
        bgCycle = $("body").backgroundCycle({
          imageUrls: [
            "img/photo-02.webp",
            "img/photo-03.jpg",
            "img/photo-04.jpg",
            "img/photo-05.jpg"
          ],
          fadeSpeed: 2000,
          duration: -1,
          backgroundSize: SCALING_MODE_COVER
        });

        eachNavLink = $(".tm-nav-link");
        links = $(".tm-nav-links");

        // "Menu" open/close
        if (links.hasClass("open")) {
          links.fadeIn(0);
        } else {
          links.fadeOut(0);
        }

        $("#tm_about_link").on("click", navLinkClick);
        $("#tm_work_link").on("click", navLinkClick);

        // Each menu item click
        eachNavLink.on("click", navLinkClick);

        $(".tm-navbar-menu").click(function(e) {
          if (links.hasClass("open")) {
            links.fadeOut();
          } else {
            links.fadeIn();
          }

          links.toggleClass("open");
        });

        // window resize
        $(window).resize(function() {
          // If current page is Gallery page, set it up
          if (currentImageId === 2) {
            setupSlider();
          }

          // Adjust footer
          adjustFooter();
        });

        adjustFooter();
      }); // DOM is ready

      function adjustFooter() {
        const windowHeight = $(window).height();
        const topHeight = $(".tm-top-container").height();
        const middleHeight = $(".tm-content").height();
        let contentHeight = topHeight + middleHeight;

        if (pageAlign === "left") {
          contentHeight += $(".tm-bottom-container").height();
        }

        if (contentHeight > windowHeight) {
          $(".tm-bottom-container").addClass("tm-static");
        } else {
          $(".tm-bottom-container").removeClass("tm-static");
        }
      }

      function setupSlider() {
        let slidesToShow = 4;
        let slidesToScroll = 2;
        let windowWidth = $(window).width();

        if (windowWidth < 480) {
          slidesToShow = 1;
          slidesToScroll = 1;
        } else if (windowWidth < 768) {
          slidesToShow = 2;
          slidesToScroll = 1;
        } else if (windowWidth < 992) {
          slidesToShow = 3;
          slidesToScroll = 2;
        }

        if (slickInitDone) {
          $(".tm-gallery").slick("unslick");
        }

        slickInitDone = true;

        $(".tm-gallery").slick({
          dots: true,
          customPaging: function(slider, i) {
            var thumb = $(slider.$slides[i]).data();
            return `<a>${i + 1}</a>`;
          },
          infinite: true,
          prevArrow: false,
          nextArrow: false,
          slidesToShow: slidesToShow,
          slidesToScroll: slidesToScroll
        });

        // Open big image when a gallery image is clicked.
        $(".slick-list").magnificPopup({
          delegate: "a",
          type: "image",
          gallery: {
            enabled: true
          }
        });
      }
    </script>
  </body>
</html>
